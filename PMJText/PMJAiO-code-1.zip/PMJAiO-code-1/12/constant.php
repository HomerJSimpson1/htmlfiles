<?php
define("THE_YEAR", "2017");
echo "It is the year ".THE_YEAR;
?>
