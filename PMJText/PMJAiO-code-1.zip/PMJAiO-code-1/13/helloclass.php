<?php
class myClass {
	function sayHello() {
		echo "HELLO!";
	}
}
$object1 = new myClass();
$object1 -> sayHello();
?>
