<?php
$num = 1;
do {
	echo "The number is: ".$num."<br>";
	$num++;
} while (($num > 200) && ($num < 400));
?>
