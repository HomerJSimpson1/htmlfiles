<?php
function printBR($txt)
{
	echo $txt."<br>";
}
printBR("This is a line.");
printBR("This is a new line.");
printBR("This is yet another line.");
?>
