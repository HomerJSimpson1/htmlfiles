<?php
function addNums($firstnum, $secondnum)
{
	$result = $firstnum + $secondnum;
	return $result;
}
echo addNums(3,5);
//will print "8"
?>
