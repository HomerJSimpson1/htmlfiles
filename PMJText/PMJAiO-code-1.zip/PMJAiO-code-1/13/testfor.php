<?php
for ($counter=1; $counter<=12; $counter++) {
	echo $counter." times 2 is ".($counter * 2)."<br>";
}
?>
