<?php
for ($counter=1; $counter <= 10; $counter++) {
	$temp = 4000/$counter;
	echo "4000 divided by ".$counter." is... $temp<br>";
}
?>
