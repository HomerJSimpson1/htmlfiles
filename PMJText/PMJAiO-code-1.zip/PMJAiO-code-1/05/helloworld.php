<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Some PHP Embedded Inside HTML</title>
  </head>
  <body>
     <h1><?php echo "Hello World!"; ?></h1>
  </body>
</html>
