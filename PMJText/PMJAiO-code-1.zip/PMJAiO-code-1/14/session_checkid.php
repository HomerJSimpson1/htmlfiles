<?php
session_start();
echo "<p>Your session ID is ".session_id().".</p>";
?>
