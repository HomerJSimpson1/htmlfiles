// <!--
//  <!-- include jquery, bootstrap and our stylesheet -->
//  <script src="http://code.jquery.com/jquery-1.11.3.min.js"></script>
// -->

//  <script type="text/javascript">
    $("#mytitle").text("My Page");
    $("#tophdr").text("My Header");
//  </script>

